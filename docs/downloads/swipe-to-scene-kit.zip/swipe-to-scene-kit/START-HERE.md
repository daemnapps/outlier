# Swipe → Scene — the production kit

Built 2026-09-04 · 34 formats · 210 torn-down references

Everything here came from real posts that already worked. Nothing is theory.

## How to use it

1. **Pick a format** in `formats/`. Each folder is one proven structure —
   read its `00-THE-FORMAT.md` first: what it is, why it works, the beats.
2. **Watch a reference.** Every `.md` in the folder is one real post torn
   down beat by beat, with its link at the bottom. `frames/` shows the six
   beats as one picture if you would rather not open the video.
   The video files themselves live on the shared drive: `Shared Assets ▸ lab ▸ damon ▸ swipe-organic ▸ records ▸ swipe-videos ▸ <code> ▸ video.mp4`
3. **Build the scenes.** Copy the Higgsfield image and motion prompts and
   run them in the Higgsfield employee: https://higgsfield.ai/supercomputer/skills?employeeId=0d38d619-0ac2-45c9-bfd5-3371837ccad3
   Fill every `{PLACEHOLDER}` from the brief you were given — never invent
   a product, a wardrobe or a room.
4. **Cut it to the beats.** The beat table in each sheet is the edit.

## The rules that matter

- **Rebuild the structure, not the content.** Different product, same shape.
  A scalp treatment and a countertop demo can be the same format.
- **Nothing invented.** If the brief does not state how the product looks,
  what the person is wearing, or what room it is — ask. A generated frame
  that guesses is worse than no frame.
- **No on-screen text beyond the pattern** the format states.
- **No claim the product has not been shown to deliver.**

## The formats, by how often they show up in the swipes

- **Running caption over borrowed cutaways** — 15 references — `formats/running-caption-over-borrowed-cutaways/`
- **Pinned line acted out** — 12 references — `formats/pinned-line-acted-out/`
- **Wordless single-take procedure** — 9 references — `formats/wordless-single-take-procedure/`
- **Sticky-line maker demo** — 9 references — `formats/sticky-line-maker-demo/`
- **Split-screen mechanism verdict** — 7 references — `formats/split-screen-mechanism-verdict/`
- **Reaction-panel repost** — 6 references — `formats/reaction-panel-repost/`
- **Filth-extraction montage** — 6 references — `formats/filth-extraction-montage/`
- **Day-count self-test** — 6 references — `formats/day-count-self-test/`
- **Character sketch** — 6 references — `formats/character-sketch/`
- **Unfinished line, real payoff** — 5 references — `formats/unfinished-line-real-payoff/`
- **Self-demo on the operator's own body** — 5 references — `formats/self-demo-on-the-operator-s-own-body/`
- **Public reaction, repeat demo** — 5 references — `formats/public-reaction-repeat-demo/`
- **Pinned-headline monologue** — 5 references — `formats/pinned-headline-monologue/`
- **Deadpan reaction hold** — 5 references — `formats/deadpan-reaction-hold/`
- **Captioned steps, comment gate** — 5 references — `formats/captioned-steps-comment-gate/`
- **Word-per-beat procedure** — 4 references — `formats/word-per-beat-procedure/`
- **Stunt funnel reveal** — 4 references — `formats/stunt-funnel-reveal/`
- **One product, unrelated worlds** — 4 references — `formats/one-product-unrelated-worlds/`
- **Era-stamped upgrade ladder** — 4 references — `formats/era-stamped-upgrade-ladder/`
- **Word-per-beat internal reveal** — 3 references — `formats/word-per-beat-internal-reveal/`
- **Labelled cutaway mechanism** — 3 references — `formats/labelled-cutaway-mechanism/`
- **Deadpan caption, evidence pile-up** — 3 references — `formats/deadpan-caption-evidence-pile-up/`
- **Wordless POV handoff transformation** — 2 references — `formats/wordless-pov-handoff-transformation/`
- **Silent build to withheld reveal** — 2 references — `formats/silent-build-to-withheld-reveal/`
- **Pinned line, stranger sighting** — 2 references — `formats/pinned-line-stranger-sighting/`
- **Pinned line, borrowed intercut** — 2 references — `formats/pinned-line-borrowed-intercut/`
- **Locked-macro debris lift** — 2 references — `formats/locked-macro-debris-lift/`
- **Locked-frame escalating caption** — 2 references — `formats/locked-frame-escalating-caption/`
- **Found clip, reaction cut** — 2 references — `formats/found-clip-reaction-cut/`
- **Flat label, damage, reaction** — 2 references — `formats/flat-label-damage-reaction/`
- **Concern list with proof photos** — 2 references — `formats/concern-list-with-proof-photos/`
- **Caption-only single take** — 2 references — `formats/caption-only-single-take/`
- **Objection-flip collection** — 1 references — `formats/objection-flip-collection/`
- **Forbidden tease → dark reveal** — 1 references — `formats/forbidden-tease-dark-reveal/`

### One-offs (46 structures seen once each)

Each keeps its own folder under `formats/one-offs/` with its sheet — a
structure earns a full card once a second swipe shows the same shape.

- `formats/one-offs/subtitled-monologue-angle-cuts/`
- `formats/one-offs/transformation-hook-mechanism-explainer/`
- `formats/one-offs/spoken-caption-applied-demo/`
- `formats/one-offs/personified-mechanism-explainer/`
- `formats/one-offs/multicam-monologue-crowd-cutaway/`
- `formats/one-offs/instruction-card-routine/`
- `formats/one-offs/clause-chain-mechanism-demo/`
- `formats/one-offs/wordless-unbox-self-demo/`
- `formats/one-offs/wordless-contact-demo-object-lift/`
- `formats/one-offs/uncaptioned-selfie-monologue/`
- `formats/one-offs/two-state-graphic-monologue/`
- `formats/one-offs/transparent-body-process-reveal/`
- `formats/one-offs/skit-open-captioned-pitch/`
- `formats/one-offs/silent-procedure-delayed-before/`
- `formats/one-offs/self-demo-open-verdict/`
- `formats/one-offs/screen-record-walkthrough-face-inset/`
- `formats/one-offs/running-caption-borrowed-cutaways/`
- `formats/one-offs/repeated-caption-timeline-montage/`
- `formats/one-offs/question-card-borrowed-answer/`
- `formats/one-offs/posed-portrait-staged-vignettes/`
- `formats/one-offs/pinned-tease-archive-montage/`
- `formats/one-offs/ordeal-then-aftermath/`
- `formats/one-offs/mock-documentary-interview-cuts/`
- `formats/one-offs/mascot-reaction-elimination/`
- `formats/one-offs/locked-frame-screen-readout/`
- `formats/one-offs/labelled-object-comparison-monologue/`
- `formats/one-offs/labelled-before-after-selfie/`
- `formats/one-offs/glowing-hazard-object-chain/`
- `formats/one-offs/giant-word-hero-teaser/`
- `formats/one-offs/found-still-caption-escalation/`
- `formats/one-offs/floating-head-restoration-reveal/`
- `formats/one-offs/fixed-subject-cast-swap/`
- `formats/one-offs/failed-advice-list/`
- `formats/one-offs/everyone-brings-one/`
- `formats/one-offs/everyday-object-hazard-reveal/`
- `formats/one-offs/eavesdrop-walk-in-subtitles/`
- `formats/one-offs/dropped-premise-subtitled-skit/`
- `formats/one-offs/dropped-hook-roaming-monologue/`
- `formats/one-offs/dated-archive-playback-cut/`
- `formats/one-offs/cut-to-verdict-card/`

## Running the teardown yourself

`the-teardown-process/` holds the chain that produced these sheets:
`how-it-works.md` explains it, and the stage prompts are the process
itself, in order — read a video, make it ours, write the hooks, write
the brief, make the pictures.
