# Subtitled Monologue Evidence Cutaways

**A one-off** — this structure appears once in the swipes, so it has no
library card yet. The sheets here carry everything known about it.

## What carries the value

The credential frame — a man in scrubs behind a steel table in a working clinic room — cashed in by full-frame evidence he cuts away to: the anatomical models, then the macro of crusted fibre, then the dose blooming through water. The macro is the beat that turns the talk into something the viewer watches happen rather than hears asserted.

## Produce it

Prompts are inside each sheet. Run them in the Higgsfield employee: https://higgsfield.ai/supercomputer/skills?employeeId=0d38d619-0ac2-45c9-bfd5-3371837ccad3
