# Running Caption Borrowed Cutaways

**A one-off** — this structure appears once in the swipes, so it has no
library card yet. The sheets here carry everything known about it.

## What carries the value

The borrowed material pasted into her frame — strangers' before close-ups, a stock mechanism diagram, competing marketplace listings. She shoots none of it; it is what turns an unbroken opinion into something that reads as evidence, and the running caption keeps the sentence unfinished so the viewer stays through each paste-in.

## Produce it

Prompts are inside each sheet. Run them in the Higgsfield employee: https://higgsfield.ai/supercomputer/skills?employeeId=0d38d619-0ac2-45c9-bfd5-3371837ccad3
