# Locked Frame Screen Readout

**A one-off** — this structure appears once in the swipes, so it has no
library card yet. The sheets here carry everything known about it.

## What carries the value

The document on the laptop screen — labelled sections, each one written out and backed by a small grid of photographs, stacking up beat after beat inside a frame where nothing else changes; the two blank one-word screens ('Rabbits' at the open, 'Crickets' at the close) bookend it as chapter cards. The face, the car and the caption are constants; the deck is the only moving part, so the deck is the argument.

## Produce it

Prompts are inside each sheet. Run them in the Higgsfield employee: https://higgsfield.ai/supercomputer/skills?employeeId=0d38d619-0ac2-45c9-bfd5-3371837ccad3
