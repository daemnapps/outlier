# Instruction Card Routine

**A one-off** — this structure appears once in the swipes, so it has no
library card yet. The sheets here carry everything known about it.

## What carries the value

The prescription: a rep count that never leaves the screen, one technique correction per beat, and a named muscle diagram pasted in beside the move — the overlay turns face-touching into something you can save and do tonight, while the borrowed before/after card up front supplies the result it is promising.

## Produce it

Prompts are inside each sheet. Run them in the Higgsfield employee: https://higgsfield.ai/supercomputer/skills?employeeId=0d38d619-0ac2-45c9-bfd5-3371837ccad3
