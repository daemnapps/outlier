# Personified Mechanism Explainer

**A one-off** — this structure appears once in the swipes, so it has no
library card yet. The sheets here carry everything known about it.

## What carries the value

The personified subject: an invisible mechanism (porosity) is given a body, so you watch something happen TO a character instead of hearing a claim — and the glass-of-water beat turns it into a test the viewer can run on themselves tonight.

## Produce it

Prompts are inside each sheet. Run them in the Higgsfield employee: https://higgsfield.ai/supercomputer/skills?employeeId=0d38d619-0ac2-45c9-bfd5-3371837ccad3
