# Personified Mechanism Explainer

**A one-off** — this structure appears once in the swipes, so it has no
library card yet. The sheets here carry everything known about it.

## What carries the value

The cross-section — you watch the trapped hair, the blade, the cream and the liquid act on the follicle below the skin, so the claim is something you see happen rather than something you are told; the mascot's pointing-then-cheering bookends turn that render into a before/after you can read in one second.

## Produce it

Prompts are inside each sheet. Run them in the Higgsfield employee: https://higgsfield.ai/supercomputer/skills?employeeId=0d38d619-0ac2-45c9-bfd5-3371837ccad3
