# Spoken Caption Applied Demo

**A one-off** — this structure appears once in the swipes, so it has no
library card yet. The sheets here carry everything known about it.

## What carries the value

The opening macro of the liquid foaming directly on the eye — a shot nobody expects to be shown, and one the viewer can only judge by watching; the product-in-hand beats are only the shopping list under it.

## Produce it

Prompts are inside each sheet. Run them in the Higgsfield employee: https://higgsfield.ai/supercomputer/skills?employeeId=0d38d619-0ac2-45c9-bfd5-3371837ccad3
