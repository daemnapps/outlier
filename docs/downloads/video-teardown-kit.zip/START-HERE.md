# Video Teardown — the engine

Any video that already worked goes in. A shot-ready brief for **your** brand
comes out: the scenes, what is said, the wardrobe, the hooks, and a prompt for
every frame you need to generate.

It works on anything — a competitor's ad, an organic post, a creator video you
were sent. The machine has no opinion about your brand; it reads one folder to
learn that, fresh on every run.

## What you need

1. **This folder.**
2. **Your brand folder** — `your-brand-folder/` here is the empty template.
   Fill it in once (its README says how and in what order). Nothing runs well
   on an empty one: the chain will tell you what it is missing rather than
   invent it.
3. **A video**, and something that can watch it. The chain is written to be
   run by an AI assistant that can read video and files — Claude Code is what
   it was built against.

## How to run it

Work through `the-chain/` in order. Each file is one stage, written as the
instruction for that stage — you hand it the video (or the previous stage's
output) plus your brand folder, and it writes that stage's output.

 1. `the-chain/stage-0-triage`
 2. `the-chain/stage-1-teardown`
 3. `the-chain/stage-1b-audience`
 4. `the-chain/stage-2-replication`
 5. `the-chain/stage-3-injection`
 6. `the-chain/stage-4-loop`
 7. `the-chain/stage-5-brief`
 8. `the-chain/stage-6-frames`
 9. `the-chain/stage-7-inject`
10. `the-chain/stage-7b-page`
11. `the-chain/stage-8-profile`

Stage 0 decides what kind of video it is, and everything downstream follows
that call. Stage 1 writes down every scene. Stage 2 turns it into a spec you
could rebuild. Stage 3 puts your brand in. The stage-4 loop writes the hooks
and the middle. Stage 5 is the brief a maker actually receives. Stage 6 puts
a reference picture on every scene.

You do not have to run all of them. Stages 1–3 alone give you a brand-injected
spec; stage 5 is where it becomes something you can hand to an editor.

## The two rules

**Rebuild the structure, not the content.** The shape earned the views. Your
product is what changes.

**Nothing invented.** If your brand folder does not say what the product looks
like or what the person wears, the chain says so instead of guessing. Fill the
gap rather than accepting the guess.

## What is not in here yet

The automated runner — the version that watches the video, runs all thirteen
stages unattended and writes the brief into a Google Doc — needs API keys and
a Drive connection, so it ships separately. `how-the-machine-works.md` is its
doctrine and describes what that adds.

---

*Open Source Outliers — daemn.co. MIT licensed.*
