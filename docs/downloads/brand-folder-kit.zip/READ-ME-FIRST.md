# Your brand folder

Rename `your-brand/` to your brand, then fill it in — `your-brand/README.md`
tells you what each file is for and the order to do it in.

Every tool in the kit reads this one folder, so this is the only setup you do.
Drop it beside the teardown chain (or anywhere the tools can see it) and point
a run at it by name.
